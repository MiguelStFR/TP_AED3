package TP_AED3_soqMelhor;



import java.math.BigInteger;

public class ChavePrivada {
    
    //GERAÇÃO CHAVE PRIVADA
        public BigInteger n;
        public BigInteger d;

        public ChavePrivada(BigInteger n, BigInteger d) {
            this.n = n;
            this.d = d;
        }

        // public BigInteger getN() {
        //     return n;
        // }

        // public BigInteger getD() {
        //     return d;
        // }
    }

